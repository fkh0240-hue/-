package com.example

import com.example.data.ChannelConstants
import com.example.data.VideoType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MohammadOrdUnitTest {

    @Test
    fun testBrandConstants() {
        assertEquals("محمد ارد", ChannelConstants.CHANNEL_NAME)
        assertEquals("1234", ChannelConstants.ADMIN_PIN)
        assertTrue(ChannelConstants.CHANNEL_BIO.contains("محمد ارد"))
    }

    @Test
    fun testVideoTypes() {
        assertEquals("ویدیو بلند", VideoType.LONG.faTitle)
        assertEquals("شورتز (کوتاه)", VideoType.SHORT.faTitle)
    }
}
