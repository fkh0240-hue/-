package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Mohammad Ord Brand Palette - Luxury Dark Theme
val BackgroundBlack = Color(0xFF0C0C10)
val SurfaceDark = Color(0xFF16161E)
val SurfaceElevated = Color(0xFF20202C)
val SurfaceVariantDark = Color(0xFF282838)

// Accent Colors
val BrandCrimson = Color(0xFFE50914) // Cinematic vibrant red
val BrandCrimsonDark = Color(0xFFB80710)
val BrandGold = Color(0xFFFFB800) // Golden highlights
val BrandBlueAccent = Color(0xFF388AF6)

// Text Colors
val TextPrimary = Color(0xFFF5F5F7)
val TextSecondary = Color(0xFFA0A0B2)
val TextTertiary = Color(0xFF6E6E82)

// Utility Colors
val OutlineDark = Color(0xFF2D2D3E)
val OverlayGradientStart = Color(0x00000000)
val OverlayGradientEnd = Color(0xCC0C0C10)
