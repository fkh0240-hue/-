package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.VideoEntity
import com.example.data.VideoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChannelViewModel(private val repository: VideoRepository) : ViewModel() {

    val allVideos: StateFlow<List<VideoEntity>> = repository.allVideos
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _selectedVideo = MutableStateFlow<VideoEntity?>(null)
    val selectedVideo: StateFlow<VideoEntity?> = _selectedVideo.asStateFlow()

    private val _selectedShortIndex = MutableStateFlow(0)
    val selectedShortIndex: StateFlow<Int> = _selectedShortIndex.asStateFlow()

    init {
        viewModelScope.launch {
            repository.checkAndSeedInitialData()
        }
    }

    fun selectVideo(video: VideoEntity) {
        _selectedVideo.value = video
    }

    fun clearSelectedVideo() {
        _selectedVideo.value = null
    }

    fun selectShort(video: VideoEntity, allShorts: List<VideoEntity>) {
        val index = allShorts.indexOfFirst { it.id == video.id }
        _selectedShortIndex.value = if (index >= 0) index else 0
    }

    fun addNewVideo(
        title: String,
        description: String,
        videoUrl: String,
        thumbnailUrl: String,
        videoType: String
    ) {
        viewModelScope.launch {
            repository.addVideo(
                title = title,
                description = description,
                videoUrl = videoUrl,
                thumbnailUrl = thumbnailUrl,
                videoType = videoType
            )
        }
    }

    fun deleteVideo(videoId: Long) {
        viewModelScope.launch {
            repository.deleteVideo(videoId)
            if (_selectedVideo.value?.id == videoId) {
                _selectedVideo.value = null
            }
        }
    }
}
