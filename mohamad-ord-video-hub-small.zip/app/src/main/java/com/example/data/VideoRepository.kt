package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class VideoRepository(private val videoDao: VideoDao) {

    val allVideos: Flow<List<VideoEntity>> = videoDao.getAllVideos()
    val longVideos: Flow<List<VideoEntity>> = videoDao.getLongVideos()
    val shortVideos: Flow<List<VideoEntity>> = videoDao.getShortVideos()
    val featuredVideos: Flow<List<VideoEntity>> = videoDao.getFeaturedVideos()

    suspend fun checkAndSeedInitialData() {
        withContext(Dispatchers.IO) {
            val count = videoDao.getCount()
            if (count == 0) {
                videoDao.insertAll(AppDatabase.getInitialSeedVideos())
            }
        }
    }

    suspend fun getVideoById(id: Long): VideoEntity? {
        return withContext(Dispatchers.IO) {
            videoDao.getVideoById(id)
        }
    }

    suspend fun addVideo(
        title: String,
        description: String,
        videoUrl: String,
        thumbnailUrl: String,
        videoType: String
    ): Long {
        return withContext(Dispatchers.IO) {
            val isShort = videoType == "SHORT"
            val newVideo = VideoEntity(
                title = title.trim(),
                description = description.trim(),
                videoUrl = videoUrl.trim(),
                thumbnailUrl = thumbnailUrl.trim(),
                thumbnailResId = if (isShort) com.example.R.drawable.thumb_short_vertical_1790243111331 else com.example.R.drawable.thumb_studio_gear_1790242797129,
                videoType = videoType,
                durationText = if (isShort) "۰۰:۵۰" else "۱۲:۰۰",
                viewsCount = "۱ بازدید",
                publishDate = "همین الان",
                likesCount = 1,
                isFeatured = false,
                isTrending = true,
                tags = "جدید,محمد ارد",
                createdAt = System.currentTimeMillis()
            )
            videoDao.insert(newVideo)
        }
    }

    suspend fun deleteVideo(videoId: Long) {
        withContext(Dispatchers.IO) {
            videoDao.deleteById(videoId)
        }
    }

    suspend fun updateVideo(video: VideoEntity) {
        withContext(Dispatchers.IO) {
            videoDao.update(video)
        }
    }
}
