package com.example.data;

/**
 * Video Type specification: Long Video vs Short.
 */
public enum VideoType {
    LONG("ویدیو بلند"),
    SHORT("شورتز (کوتاه)");

    private final String faTitle;

    VideoType(String faTitle) {
        this.faTitle = faTitle;
    }

    public String getFaTitle() {
        return faTitle;
    }
}
