package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.data.AppDatabase
import com.example.data.VideoEntity
import com.example.data.VideoRepository
import com.example.ui.ChannelViewModel
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.ChannelHomeScreen
import com.example.ui.screens.ShortsFeedScreen
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.theme.BackgroundBlack
import com.example.ui.theme.MyApplicationTheme

enum class ScreenState {
    HOME,
    PLAYER,
    SHORTS,
    ADMIN
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val repository = VideoRepository(database.videoDao())
        val viewModel = ChannelViewModel(repository)

        setContent {
            MyApplicationTheme {
                // Force RTL Layout for Persian brand experience
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = BackgroundBlack
                    ) {
                        MohammadOrdApp(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun MohammadOrdApp(viewModel: ChannelViewModel) {
    var currentScreen by remember { mutableStateOf(ScreenState.HOME) }
    val allVideos by viewModel.allVideos.collectAsState()
    val selectedVideo by viewModel.selectedVideo.collectAsState()
    val selectedShortIndex by viewModel.selectedShortIndex.collectAsState()

    val shortVideos = remember(allVideos) { allVideos.filter { it.videoType == "SHORT" } }

    Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
        when (screen) {
            ScreenState.HOME -> {
                ChannelHomeScreen(
                    allVideos = allVideos,
                    onVideoClick = { video ->
                        viewModel.selectVideo(video)
                        currentScreen = ScreenState.PLAYER
                    },
                    onShortClick = { shortVideo ->
                        viewModel.selectShort(shortVideo, shortVideos)
                        currentScreen = ScreenState.SHORTS
                    },
                    onAdminClick = {
                        currentScreen = ScreenState.ADMIN
                    }
                )
            }

            ScreenState.PLAYER -> {
                selectedVideo?.let { video ->
                    VideoPlayerScreen(
                        video = video,
                        recommendedVideos = allVideos,
                        onVideoSelected = { newVid ->
                            viewModel.selectVideo(newVid)
                        },
                        onBackClick = {
                            viewModel.clearSelectedVideo()
                            currentScreen = ScreenState.HOME
                        }
                    )
                } ?: run {
                    currentScreen = ScreenState.HOME
                }
            }

            ScreenState.SHORTS -> {
                ShortsFeedScreen(
                    shorts = shortVideos,
                    initialIndex = selectedShortIndex,
                    onBackClick = {
                        currentScreen = ScreenState.HOME
                    }
                )
            }

            ScreenState.ADMIN -> {
                AdminPanelScreen(
                    videos = allVideos,
                    onAddVideo = { title, desc, url, thumb, type ->
                        viewModel.addNewVideo(title, desc, url, thumb, type)
                    },
                    onDeleteVideo = { id ->
                        viewModel.deleteVideo(id)
                    },
                    onBackClick = {
                        currentScreen = ScreenState.HOME
                    }
                )
            }
        }
    }
}
